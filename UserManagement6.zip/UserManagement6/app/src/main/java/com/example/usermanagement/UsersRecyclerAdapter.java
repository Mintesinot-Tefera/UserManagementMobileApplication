package com.example.usermanagement;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.zip.Inflater;

public class UsersRecyclerAdapter extends RecyclerView.Adapter<UsersRecyclerAdapter.UserViewHolder> {

    private List<User> listUsers;

    public UsersRecyclerAdapter(List<User> listUsers) {
        this.listUsers = listUsers;
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // inflating recycler item view
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_users_data, parent, false);
        return new UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, int position) {
        holder.textViewFullName.setText(listUsers.get(position).getFullName());
        holder.textViewUsername.setText(listUsers.get(position).getUsername());
        holder.textViewEmail.setText(listUsers.get(position).getEmail());
        holder.textViewPhone.setText(listUsers.get(position).getPhone());
       // holder.textViewGender.setText(listUsers.get(position).getPassword());
    }

    @Override
    public int getItemCount() {
        if(listUsers == null)
            return 0;
        else{
            Log.v(UsersRecyclerAdapter.class.getSimpleName(),""+ listUsers.size());
        return listUsers.size();
    }}

    /**
     * ViewHolder class
     */
    public class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewFullName;
        public TextView textViewUsername;
        public TextView textViewEmail;
        public TextView textViewGender;
        public TextView textViewPhone;

        public UserViewHolder(View view) {
            super(view);
            textViewFullName =  view.findViewById(R.id.textViewFullname);
            textViewUsername = view.findViewById(R.id.textViewUsername);
            textViewEmail = view.findViewById(R.id.textViewEmail);
            textViewPhone = view.findViewById(R.id.textViewPhonenumber);
//            textViewGender = view.findViewById(R.id.textViewGender);
        }
    }
}
