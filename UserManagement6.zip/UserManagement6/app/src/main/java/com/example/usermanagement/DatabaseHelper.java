package com.example.usermanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "UserManagement.db";
    // User table name
    private static final String TABLE_USER = "user";
    // User Table Columns names
//    private static final String COL_FULLNAME = "user_fullname";
//    private static final String COL_USERNAME = "user_name";
//    private static final String COL_EMAIL = "user_email";
//    private static final String COL_PASSWORD = "user_password";
//    private static final String COL_MOBILE = "user_mobile";
//    private static final String COL_GENDER = "User_gender";

    private String Create_user_table = "CREATE TABLE "+TABLE_USER+"(Full_name TEXT,User_name TEXT," +
            "Email TEXT,Password TEXT,Mobile TEXT)";

//    ,Gender TEXT

    private String Drop_user_table="DROP TABLE IF EXISTS "+ TABLE_USER;

    public DatabaseHelper( Context context ) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Create_user_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop User Table if exist
        db.execSQL(Drop_user_table);
// Create tables again
        onCreate(db);
    }
    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Full_name", user.getFullName());
        values.put("User_name", user.getUsername());
        values.put("Email", user.getEmail());
        values.put("Password", user.getPassword());
        values.put("Mobile", user.getPhone());
        //values.put("Gender", user.getGender());

// Inserting Row
        db.insert(TABLE_USER, null, values);
        db.close();
    }

    public List<User> getAllUser() {
// array of columns to fetch
        String[] columns = {
                "Full_name",
                "User_name",
                "Email",
                "Password",
                "Mobile",
               // "Gender"
        };

        List<User> userList = new ArrayList<User>();
        SQLiteDatabase db = this.getReadableDatabase();


        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns, //columns to return
                null, //columns for the WHERE clause
                null, //The values for the WHERE clause
                null, //group the rows
                null, //filter by row groups
                null); //The sort order
// Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setFullName(cursor.getString(cursor.getColumnIndex("Full_name" )));
                user.setUsername(cursor.getString(cursor.getColumnIndex("User_name")));
                user.setEmail(cursor.getString(cursor.getColumnIndex("Email")));
                user.setPassword(cursor.getString(cursor.getColumnIndex("Password")));
                user.setPhone(cursor.getString(cursor.getColumnIndex("Mobile")));
                //user.setGender(cursor.getString(cursor.getColumnIndex("Gender")));
// Adding user record to list
                        userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
// return user list
        return userList;
    }
    public boolean checkUser(String email) {
// array of columns to fetch
        String[] columns = {
                "User_name"
        };
        SQLiteDatabase db = this.getReadableDatabase();
// selection criteria
        String selection = "Email = ?";
// selection argument
        String[] selectionArgs = {email};
// query user table with condition

        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns, //columns to return
                selection, //columns for the WHERE clause
                selectionArgs, //The values for the WHERE clause
                null, //group the rows
                null, //filter by row groups
                null); //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }

    public boolean checkUser(String username, String password) {
// array of columns to fetch
        String[] columns = {"Full_name",
                "User_name",
                "Email",
                "Mobile",};
        SQLiteDatabase db = this.getReadableDatabase();
// selection criteria
        String selection = "User_name = ? AND Password  = ?";

// selection arguments
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns, //columns to return
                selection, //columns for the WHERE clause
                selectionArgs, //The values for the WHERE clause
                null, //group the rows
                null, //filter by row groups
                null); //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }
}

