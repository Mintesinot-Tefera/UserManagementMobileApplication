package com.example.usermanagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

public class Signup extends AppCompatActivity implements View.OnClickListener {
    private final AppCompatActivity activity = Signup.this;
    private NestedScrollView nestedScrollView;

    private TextInputLayout textInputLayoutUsername2;
    private TextInputLayout textInputLayoutPassword2;
    private TextInputLayout textInputLayoutFullname;
    private TextInputLayout textInputLayoutEmail;
    private TextInputLayout textInputLayoutPhone;

    private TextInputEditText textInputEditTextUsername2;
    private TextInputEditText textInputEditTextPassword2;
    private TextInputEditText textInputEditTextFullname;
    private TextInputEditText textInputEditTextEmail;
    private TextInputEditText textInputEditTextPhone;
    private Button btnSignup2;
    private TextView textViewLogin;

    private InputValidation inputValidation;
    private DatabaseHelper databaseHelper;
    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();

        initViews();
        initListeners();
        initObjects();
    }
    private void initViews() {
        nestedScrollView = findViewById(R.id.nestedScrollView);
        textInputLayoutUsername2= findViewById(R.id.textInputLayoutUsername2);
        textInputLayoutPassword2= findViewById(R.id.textInputLayoutPassword2);
        textInputLayoutFullname= findViewById(R.id.textInputLayoutFullname);
        textInputLayoutEmail= findViewById(R.id.textInputLayoutEmail);
        textInputLayoutPhone= findViewById(R.id.textInputLayoutPhone);

        textInputEditTextUsername2= findViewById(R.id.textInputEditTextUsername2);
        textInputEditTextPassword2= findViewById(R.id.textInputEditTextPassword2);
        textInputEditTextFullname= findViewById(R.id.textInputEditTextFullname);
        textInputEditTextEmail= findViewById(R.id.textInputEditTextEmail);
        textInputEditTextPhone= findViewById(R.id.textInputEditTextPhone);

        textViewLogin = findViewById(R.id.textViewAlreadyHaveAccount);
        btnSignup2 = findViewById(R.id.btnSignup2);

        nestedScrollView = (NestedScrollView) findViewById(R.id.nestedScrollView);

    }

    /**
     * This method is to initialize listeners
     */

    private void initListeners() {
        btnSignup2.setOnClickListener(this);
        textViewLogin.setOnClickListener(this);

    }

    /**
     * This method is to initialize objects to be used
     */
    private void initObjects() {
        inputValidation = new InputValidation(activity);
        databaseHelper = new DatabaseHelper(activity);
        user = new User();
    }
    /**
     * This implemented method is to listen the click on view
     *
     * @param v
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btnSignup2:
                postDataToSQLite();
                break;

            case R.id.textViewAlreadyHaveAccount:
                finish();
                break;
        }
    }

    /**
     * This method is to validate the input text fields and post data to SQLite
     */
    private void postDataToSQLite() {
        if (!inputValidation.isInputEditTextFilled(textInputEditTextFullname, textInputLayoutFullname,"Enter Full Name")) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextUsername2, textInputLayoutUsername2, "Enter User name")) {
            return;
        }
        if (!inputValidation.isInputEditTextEmail(textInputEditTextEmail, textInputLayoutEmail, "Enter valid Email")) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextPassword2, textInputLayoutPassword2, "Enter valid Password")) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextPhone, textInputLayoutPhone, "Enter valid Phone number")) {
            return;
        }

        if (!databaseHelper.checkUser(textInputEditTextEmail.getText().toString().trim())) {

            user.setFullName(textInputEditTextFullname.getText().toString().trim());
            user.setUsername(textInputEditTextUsername2.getText().toString().trim());
            user.setEmail(textInputEditTextEmail.getText().toString().trim());
            user.setPassword(textInputEditTextPassword2.getText().toString().trim());
            user.setPhone(textInputEditTextPhone.getText().toString().trim());

            databaseHelper.addUser(user);

            // Snack Bar to show success message that record saved successfully
            //Snackbar.make(nestedScrollView, "Registration Successful", Snackbar.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_LONG).show();
            emptyInputEditText();

        } else {
            // Snack Bar to show error message that record already exists
//            Snackbar.make(nestedScrollView, "Email Already Exists", Snackbar.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), "Email Already Exists", Toast.LENGTH_LONG).show();

        }
    }

    /**
     * This method is to empty all input edit text
     */
    private void emptyInputEditText() {
        textInputEditTextFullname.setText(null);
        textInputEditTextUsername2.setText(null);
        textInputEditTextEmail.setText(null);
        textInputEditTextPassword2.setText(null);
        textInputEditTextPhone.setText(null);
    }
}

