package com.example.usermanagement;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Arrays;

public class UsersData extends AppCompatActivity {

    private RecyclerView.LayoutManager layoutManager;
    //private RecyclerAdapter recyclerAdapter;

    private AppCompatActivity activity = UsersData.this;
    private TextView textViewName;
    private RecyclerView recyclerViewUsers;
    private List<User> listUsers;
    private UsersRecyclerAdapter usersRecyclerAdapter;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_data);


        recyclerViewUsers = findViewById(R.id.recyclerViewUsers);
        layoutManager = new LinearLayoutManager(this);
        recyclerViewUsers.setLayoutManager(layoutManager);
        usersRecyclerAdapter= new UsersRecyclerAdapter(listUsers);
        recyclerViewUsers.setHasFixedSize(true);
        recyclerViewUsers.setAdapter(usersRecyclerAdapter);

    }

    public class UsersListActivity extends AppCompatActivity {

        @Override
        protected void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_users_data);
            getSupportActionBar().setTitle("");
            initViews();
            initObjects();
        }
        /**
         * This method is to initialize views
         */
        private void initViews() {
            textViewName =  findViewById(R.id.textViewName);
            recyclerViewUsers =  findViewById(R.id.recyclerViewUsers);
        }
        /**
         * This method is to initialize objects to be used
         */
        private void initObjects() {
            listUsers = new ArrayList<>();
            usersRecyclerAdapter = new UsersRecyclerAdapter(listUsers);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                    recyclerViewUsers.setLayoutManager(mLayoutManager);
            recyclerViewUsers.setItemAnimator(new DefaultItemAnimator());
            recyclerViewUsers.setHasFixedSize(true);
            recyclerViewUsers.setAdapter(usersRecyclerAdapter);
            databaseHelper = new DatabaseHelper(activity);
            String emailFromIntent = getIntent().getStringExtra("EMAIL");
            textViewName.setText(emailFromIntent);
            getDataFromSQLite();
        }
        /**
         * This method is to fetch all user records from SQLite
         */
        private void getDataFromSQLite() {
// AsyncTask is used that SQLite operation not blocks the UI Thread.
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    listUsers.clear();
                    listUsers.addAll(databaseHelper.getAllUser());
                    return null;
                }
                @Override
                protected void onPostExecute(Void aVoid) {
                    super.onPostExecute(aVoid);
                    usersRecyclerAdapter.notifyDataSetChanged();
                }
            }.execute();
        }
    }


}
